"# ayub-week1-project-cc" 

project Name: Portfolio Landing Page

Author Name: Ayub Gakuru Kibirio

Description of project: A Website acting as a landing page for my programming portfolio.
Project setup instructions:
  Here are the requirements for your page:
        Your name
        An image of you or something that represents who you are
        A list of projects you have created with active links to them (either on GitHub or GitHub pages)
        For each, include a brief description of the project and what languages it uses
        An "About Me" section including:
        Your background (for example, your education, job experience, a paragraph on why you decided to take a class on programming, etc.)
        Your current interests/hobbies/skills
        Deploy your site onto GitHub pages so that a live site can be viewed at your-username.github.io/portfolio (for example)
link to live site on GitHub Pages:  To be updated
copyright and license information: ©2021 Ayub Gakuru Kibirio.
